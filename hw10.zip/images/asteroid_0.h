/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 asteroid_0 asteroid_0.png 
 * Time-stamp: Sunday 04/07/2019, 13:48:37
 * 
 * Image Information
 * -----------------
 * asteroid_0.png 11@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_0_H
#define ASTEROID_0_H

extern unsigned short asteroid_0[110];
#define ASTEROID_0_SIZE 220
#define ASTEROID_0_LENGTH 110
#define ASTEROID_0_WIDTH 11
#define ASTEROID_0_HEIGHT 10

#endif

