/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 enemy_laser enemy_laser.png 
 * Time-stamp: Saturday 04/06/2019, 20:18:26
 * 
 * Image Information
 * -----------------
 * enemy_laser.png 10@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ENEMY_LASER_H
#define ENEMY_LASER_H

extern const unsigned short enemy_laser[170];
#define ENEMY_LASER_SIZE 340
#define ENEMY_LASER_LENGTH 170
#define ENEMY_LASER_WIDTH 10
#define ENEMY_LASER_HEIGHT 17

#endif

