/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 friendly_laser friendly_laser.png 
 * Time-stamp: Saturday 04/06/2019, 20:18:15
 * 
 * Image Information
 * -----------------
 * friendly_laser.png 10@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FRIENDLY_LASER_H
#define FRIENDLY_LASER_H

extern const unsigned short friendly_laser[170];
#define FRIENDLY_LASER_SIZE 340
#define FRIENDLY_LASER_LENGTH 170
#define FRIENDLY_LASER_WIDTH 10
#define FRIENDLY_LASER_HEIGHT 17

#endif

