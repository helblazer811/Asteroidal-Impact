/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 funk_1 funk_1.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:42
 * 
 * Image Information
 * -----------------
 * funk_1.png 16@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FUNK_1_H
#define FUNK_1_H

extern unsigned short funk_1[256];
#define FUNK_1_SIZE 512
#define FUNK_1_LENGTH 256
#define FUNK_1_WIDTH 16
#define FUNK_1_HEIGHT 16

#endif

