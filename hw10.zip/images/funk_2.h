/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 funk_2 funk_2.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:37
 * 
 * Image Information
 * -----------------
 * funk_2.png 14@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FUNK_2_H
#define FUNK_2_H

extern unsigned short funk_2[210];
#define FUNK_2_SIZE 420
#define FUNK_2_LENGTH 210
#define FUNK_2_WIDTH 14
#define FUNK_2_HEIGHT 15

#endif

