/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 funk_3 funk_3.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:33
 * 
 * Image Information
 * -----------------
 * funk_3.png 14@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FUNK_3_H
#define FUNK_3_H

extern unsigned short funk_3[210];
#define FUNK_3_SIZE 420
#define FUNK_3_LENGTH 210
#define FUNK_3_WIDTH 14
#define FUNK_3_HEIGHT 15

#endif

