/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 funk_4 funk_4.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:29
 * 
 * Image Information
 * -----------------
 * funk_4.png 14@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FUNK_4_H
#define FUNK_4_H

extern unsigned short funk_4[210];
#define FUNK_4_SIZE 420
#define FUNK_4_LENGTH 210
#define FUNK_4_WIDTH 14
#define FUNK_4_HEIGHT 15

#endif

