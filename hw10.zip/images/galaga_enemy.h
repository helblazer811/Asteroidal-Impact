/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 galaga_enemy galaga_enemy.png 
 * Time-stamp: Saturday 04/06/2019, 20:18:56
 * 
 * Image Information
 * -----------------
 * galaga_enemy.png 23@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GALAGA_ENEMY_H
#define GALAGA_ENEMY_H

extern const unsigned short galaga_enemy[368];
#define GALAGA_ENEMY_SIZE 736
#define GALAGA_ENEMY_LENGTH 368
#define GALAGA_ENEMY_WIDTH 23
#define GALAGA_ENEMY_HEIGHT 16

#endif

