/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 red_explosion red_explosion.png 
 * Time-stamp: Saturday 04/06/2019, 20:17:29
 * 
 * Image Information
 * -----------------
 * red_explosion.png 18@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RED_EXPLOSION_H
#define RED_EXPLOSION_H

extern const unsigned short red_explosion[306];
#define RED_EXPLOSION_SIZE 612
#define RED_EXPLOSION_LENGTH 306
#define RED_EXPLOSION_WIDTH 18
#define RED_EXPLOSION_HEIGHT 17

#endif

