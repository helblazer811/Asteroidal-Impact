/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 asteroid_1 asteroid_1.png 
 * Time-stamp: Sunday 04/07/2019, 13:48:43
 * 
 * Image Information
 * -----------------
 * asteroid_1.png 7@7
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_1_H
#define ASTEROID_1_H

extern unsigned short asteroid_1[49];
#define ASTEROID_1_SIZE 98
#define ASTEROID_1_LENGTH 49
#define ASTEROID_1_WIDTH 7
#define ASTEROID_1_HEIGHT 7

#endif

