/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 asteroid_2 asteroid_2.png 
 * Time-stamp: Sunday 04/07/2019, 13:48:49
 * 
 * Image Information
 * -----------------
 * asteroid_2.png 13@12
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_2_H
#define ASTEROID_2_H

extern unsigned short asteroid_2[156];
#define ASTEROID_2_SIZE 312
#define ASTEROID_2_LENGTH 156
#define ASTEROID_2_WIDTH 13
#define ASTEROID_2_HEIGHT 12

#endif

