/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 asteroid_3 asteroid_3.png 
 * Time-stamp: Sunday 04/07/2019, 13:48:56
 * 
 * Image Information
 * -----------------
 * asteroid_3.png 24@24
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_3_H
#define ASTEROID_3_H

extern unsigned short asteroid_3[576];
#define ASTEROID_3_SIZE 1152
#define ASTEROID_3_LENGTH 576
#define ASTEROID_3_WIDTH 24
#define ASTEROID_3_HEIGHT 24

#endif

