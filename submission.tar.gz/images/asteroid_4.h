/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 asteroid_4 asteroid_4.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:02
 * 
 * Image Information
 * -----------------
 * asteroid_4.png 28@29
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef ASTEROID_4_H
#define ASTEROID_4_H

extern unsigned short asteroid_4[812];
#define ASTEROID_4_SIZE 1624
#define ASTEROID_4_LENGTH 812
#define ASTEROID_4_WIDTH 28
#define ASTEROID_4_HEIGHT 29

#endif

