/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 blue_explosion blue_explosion.png 
 * Time-stamp: Saturday 04/06/2019, 20:18:35
 * 
 * Image Information
 * -----------------
 * blue_explosion.png 18@17
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLUE_EXPLOSION_H
#define BLUE_EXPLOSION_H

extern const unsigned short blue_explosion[306];
#define BLUE_EXPLOSION_SIZE 612
#define BLUE_EXPLOSION_LENGTH 306
#define BLUE_EXPLOSION_WIDTH 18
#define BLUE_EXPLOSION_HEIGHT 17

#endif

