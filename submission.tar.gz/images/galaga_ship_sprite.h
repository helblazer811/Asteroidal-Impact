/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 galaga_ship_sprite galaga_ship_sprite.png 
 * Time-stamp: Saturday 04/06/2019, 16:37:46
 * 
 * Image Information
 * -----------------
 * galaga_ship_sprite.png 15@16
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GALAGA_SHIP_SPRITE_H
#define GALAGA_SHIP_SPRITE_H

extern const unsigned short galaga_ship_sprite[240];
#define GALAGA_SHIP_SPRITE_SIZE 480
#define GALAGA_SHIP_SPRITE_LENGTH 240
#define GALAGA_SHIP_SPRITE_WIDTH 15
#define GALAGA_SHIP_SPRITE_HEIGHT 16

#endif

