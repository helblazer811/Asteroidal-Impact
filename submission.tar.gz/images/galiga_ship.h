/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 galiga_ship galiga_ship.png 
 * Time-stamp: Saturday 04/06/2019, 15:06:42
 * 
 * Image Information
 * -----------------
 * galiga_ship.png 60@67
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GALIGA_SHIP_H
#define GALIGA_SHIP_H

extern const unsigned short galiga_ship[4020];
#define GALIGA_SHIP_SIZE 8040
#define GALIGA_SHIP_LENGTH 4020
#define GALIGA_SHIP_WIDTH 60
#define GALIGA_SHIP_HEIGHT 67

#endif

