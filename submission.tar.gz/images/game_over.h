/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 game_over game_over.png 
 * Time-stamp: Sunday 04/07/2019, 13:49:51
 * 
 * Image Information
 * -----------------
 * game_over.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAME_OVER_H
#define GAME_OVER_H

extern const unsigned short game_over[38400];
#define GAME_OVER_SIZE 76800
#define GAME_OVER_LENGTH 38400
#define GAME_OVER_WIDTH 240
#define GAME_OVER_HEIGHT 160

#endif

