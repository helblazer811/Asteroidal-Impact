/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 heart_sprite heart_sprite.png 
 * Time-stamp: Saturday 04/06/2019, 20:17:43
 * 
 * Image Information
 * -----------------
 * heart_sprite.png 15@13
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HEART_SPRITE_H
#define HEART_SPRITE_H

extern const unsigned short heart_sprite[195];
#define HEART_SPRITE_SIZE 390
#define HEART_SPRITE_LENGTH 195
#define HEART_SPRITE_WIDTH 15
#define HEART_SPRITE_HEIGHT 13

#endif

